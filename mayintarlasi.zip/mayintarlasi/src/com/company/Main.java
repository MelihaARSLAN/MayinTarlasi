package com.company;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

class Mayinlar {

    private static Mayinlar Mayinlar;

    private Mayinlar(){}

    public synchronized static Mayinlar mayinlar(){
        if (Mayinlar==null)
            Mayinlar=new Mayinlar();
        return Mayinlar;
    }

    @Override
    public Object clone() throws CloneNotSupportedException
    {
        throw new CloneNotSupportedException("Bu sınıf birden fazla türetilemez.");
    }

    Mayin head;

    class Mayin
    {
        int mayinx;
        int mayiny;
        Mayin next;
        Mayin(int x,int y)
        {
            mayinx = x;
            mayiny = y;
            next = null;
        }
    }

    public void mayinEkle(int mayinSayisi,int tarlax,int tarlay)
    {
        Random r=new Random();
        for (int i=0;i<mayinSayisi;i++){
            Mayin mayin = new Mayin(r.nextInt(tarlax), r.nextInt(tarlay));
            mayin.next = head;
            head = mayin;
        }
    }

    public void mayinYazdir()
    {
        Mayin n = head;
        while (n != null) {
            System.out.print(n.mayinx + ","+n.mayiny+"->");
            n = n.next;
        }
    }

    public boolean mayinArama(Mayin head, int x,int y)
    {
        Mayin isaretlidugum = head;
        while (isaretlidugum != null)
        {
            if (isaretlidugum.mayinx == x && isaretlidugum.mayiny==y)
                return true;

            isaretlidugum = isaretlidugum.next;
        }
        return false;
    }

    public void mayinSifirla(){
        head=null;
    }
}

public class Main {
    public static int[][] mayinlarMatris;
    public static Scanner klavye=new Scanner(System.in);

    public static int[][] yeniOyun(){
        System.out.println("Oyun zorluk seviyesi seçiniz:");
        System.out.println("1:Kolay(9x9) 10 Mayın");
        System.out.println("2:Orta(16x16) 40 Mayın");
        System.out.println("3:Uzman(16x30) 99 Mayın");
        Mayinlar mayinlar=Mayinlar.mayinlar();
        while (true){
            try {
                switch (klavye.next()){
                    case "1":
                        mayinlar.mayinEkle(10,9,9);
                        return new int[9][9];
                    case "2":
                        mayinlar.mayinEkle(40,16,16);
                        return new int[16][16];
                    case "3":
                        mayinlar.mayinEkle(99,16,30);
                        return new int[16][30];
                    default:
                        System.out.println("Lütfen gecerli bir zorluk seviyesi giriniz.(1,2,3)");
                }
            }catch (InputMismatchException f){
                System.out.println("Zorluk seviyesi secilirken bir hata meydana geldi!");
            }

        }
    }

    public static void oyunYazdir(int[][] oyun){
        for(int x=0; x<oyun.length; x++) {
            if (x==0){
                System.out.print("    ");
                for(int z=0; z<oyun[0].length; z++) {
                    if (z<9){
                        System.out.print(z+1+"  ");
                    }else{
                        System.out.print(z+1+" ");
                    }
                }
                System.out.println();
                System.out.print("--------------------------------------------------------------------------------------------");
                System.out.println();
            }
            if (x<9){
                System.out.print(x+1+"  |");
            }else{
                System.out.print(x+1+" |");
            }
            for(int y=0; y<oyun[0].length; y++) {
                System.out.print(oyun[x][y]+"  " );
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        String[] okunan;
        int x;
        int y;
        while(true){
            mayinlarMatris=yeniOyun();
            oyunYazdir(mayinlarMatris);
            Mayinlar mayinlar=Mayinlar.mayinlar();
            System.out.println("Seçmek istediğiniz parselin kordinatlarini giriniz.(5,3)");
            try{
                while(true){
                    okunan=klavye.next().split(",");
                    x=Integer.parseInt(okunan[0]);
                    y=Integer.parseInt(okunan[1]);
                    if (x>0 && y>0 && mayinlarMatris.length>x && mayinlarMatris[0].length>y){
                        if(mayinlar.mayinArama(mayinlar.head,x,y)){
                            System.out.println("Mayina bastiniz :( Tum mayinlarin kordinatlari:");
                            mayinlar.mayinYazdir();
                            System.out.println("Yeniden oynamak için bir karakter giriniz.");
                            mayinlar.mayinSifirla();
                            klavye.next();
                            break;
                        }else{
                            mayinlarMatris[x-1][y-1]=3;
                            oyunYazdir(mayinlarMatris);
                            System.out.println("Güzel hamle, devam et.");
                        }
                    }else{
                        System.out.println("Lütfen pozitif sayıları kullanarak(5,3) formatında ve gecerli boyutta bir kordinat giriniz.");
                    }
                }

            }catch (NumberFormatException  e){
                System.out.println("Lütfen sadece belirtilen formatta(7,8) giriş yapınız!");
            }
        }



    }
}
